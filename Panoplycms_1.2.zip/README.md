# PanoplyCMS 1.1.0

PanoplyCMS is opensource CMS based on Meteor Framework. In current version it provides basic functionality like adding articles and categoies and assigning them to menu. It uses Bootstrap3 as its css framework.

# Installation
- Pull PanoplyCMS from GitHub Repository on you system OR you can download zip and extract it on your machine
- Go to folder location through terminal or command prompt
- Type: meteor and hit enter. Please wait for server to get start. It will automatically install all dependencies and will start running
- Once it start running goto you browser ant type: http://localhost:3000
- Thats it! You have installed PanoplyCMS on your system successfully

Frontend Link: http://localhost:3000
Backend Link: http://localhost:3000/admin

Initial Login Credentials on Backend:
    email: 'info@deligence.com'
    password: 'y!A;4)'

Now go and create some categories, then articles and finally some menus. Look at the changes at your frontend.

# Demo
- Frontend: http://panoplycms.meteor.com
- Backend: http://panoplycms.meteor.com/admin
- Backend Login Details
	-- Email: info@deligence.com
	-- Password: BkX5cS

# Features
- Single Admin
- Multiple Categories
- Articles Associated With Created Categories
- Multiple & Multilevel Menus
- Tags associated with articles
- HTML Blocks that can load at any given position.
