Meteor.publish('moduleList', function(){

	return PanoplyCMSCollections.Modules.find({});
});
Meteor.publish('findAModule', function(id){

	return PanoplyCMSCollections.Modules.find({_id:id});
});
