Meteor.publish('tags', function(){
	return PanoplyCMSCollections.Tags.find({trash:false});
});
Meteor.publish('findTag', function(id){
	
	return PanoplyCMSCollections.Tags.find({_id:id});
});