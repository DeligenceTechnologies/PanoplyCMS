Heading=React.createClass({
  render:function(){
    return (
          <div className="page-header">
            <h3 className="sub-header">{this.props.data}</h3>
          </div>
      )
  }
})